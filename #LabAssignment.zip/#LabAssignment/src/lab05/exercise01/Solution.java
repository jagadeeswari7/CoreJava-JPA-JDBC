package lab05.exercise01;

import java.util.Scanner;

public class Solution{
	public static void main(String[] args) throws UserDefinedException {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the age: ");
		int age= sc.nextInt();
		
		if(age<15)
			throw new UserDefinedException("Age should be above 15");
	}		
}
