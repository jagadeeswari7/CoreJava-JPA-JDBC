package lab05.exercise01;

public class UserDefinedException extends Exception {
	 public UserDefinedException(String s) {
		  super(s);
	  }
}
