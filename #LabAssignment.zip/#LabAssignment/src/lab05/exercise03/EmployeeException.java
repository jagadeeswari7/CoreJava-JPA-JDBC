package lab05.exercise03;

public class EmployeeException extends Exception {
  public EmployeeException(String s) {
	  super(s);
  }
}
