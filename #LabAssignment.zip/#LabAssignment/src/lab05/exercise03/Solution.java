package lab05.exercise03;

import java.util.Scanner;

public class Solution {
	public static void main(String[] args) throws EmployeeException {
		Scanner sc = new Scanner(System.in);
	System.out.println("Enter the salary: ");
	double sal= sc.nextDouble();
	
	if(sal<3000)
		throw new EmployeeException("Salary should be above 3000");
}
}
