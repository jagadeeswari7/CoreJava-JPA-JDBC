package lab05.exercise02;

import java.util.Scanner;

import lab05.exercise01.UserDefinedException;

public class Solution {
	public static void main(String[] args) throws UserDefinedException {
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Enter the first name: ");
	String fName = sc.next();
	
	System.out.println("Enter the last name: ");
	String lName = sc.next();
	
	if(fName.length()==0 || lName.length()==0)
		throw new UserDefinedException("First/Last Name are null");
	}
}
