package lab05.exercise02;

public class UserDefinedException extends Exception {
	 public UserDefinedException(String s) {
		  super(s);
	  }
}
