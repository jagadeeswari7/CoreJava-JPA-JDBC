package lab04.exercise01;


public class Current extends Account{
	private double overdraftLimit = 1000 ;
	private double balance;
	
    public Current(double balance) {
		super(balance);
		this.balance = balance;
	}
	
	 @Override
	    public void withdraw(double amount) {
			if(amount <(overdraftLimit +balance)) {
				System.out.println("You are good to withdraw the amount");
			}else {
				System.out.println("You dont have enough balance");
			}
	    }

}
