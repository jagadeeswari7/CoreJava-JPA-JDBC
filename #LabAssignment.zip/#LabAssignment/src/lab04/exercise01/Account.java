package lab04.exercise01;

public class Account {
 private long accNum;
 private double balance;
 
 private Person accHolder;

 public Account(double balance) {
	 this.balance = balance;
 }
 
 public void deposit(double amt) {
	 balance = balance + amt;
	 System.out.println("The balance after deposit " +amt+ " is = "+balance);
 }
 public void withdraw(double amt) {
	   if(balance >= amt) {
	   balance = balance - amt;
	   System.out.println("The balance after withdraw "+amt+" is = "+balance);
	   }else {
		   System.out.println("You don't have enough balance");
	   }
 }
 
public long getAccNum() {
	return accNum;
}

public void setAccNum(long accNum) {
	this.accNum = accNum;
}

public double getBalance() {
	return balance;
}

public void setBalance(double balance) {
	this.balance = balance;
}

public Person getAccHolder() {
	return accHolder;
}

public void setAccHolder(Person accHolder) {
	this.accHolder = accHolder;
}
 
}
