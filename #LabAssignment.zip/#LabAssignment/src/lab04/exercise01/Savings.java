package lab04.exercise01;

public class Savings extends Account{
	private static final double minBalance = 500.0;
	
	private double balance;
	public Savings( double balance) {
		super(balance);
		this.balance = balance;
	}
	
	@Override
	public void withdraw(double amount) {
		if(amount >= minBalance) {
			balance = balance - amount;
			System.out.println("The balance after withdraw "+amount+" is = "+balance);
		   }else {
			   System.out.println("You don't have enough balance");
		   }	
	}
}
