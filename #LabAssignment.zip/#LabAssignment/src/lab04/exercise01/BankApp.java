package lab04.exercise01;

public class BankApp {
	public static void main(String[] args) {
		Person person1 = new Person("Smith" , 20);
		Person person2 = new Person("Kathy" , 21);
		
		Account account1 = new Account(2000);
		account1.setAccHolder(person1);   // set-up relationship
		
		Account account2 = new Account(3000);
		account2.setAccHolder(person2);
		
		System.out.println("Smith's account: ");
		account1.deposit(2000);
		System.out.println("-----------------------------------");
		System.out.println("Kathy's Account: ");
		account2.withdraw(2000);
		
		
		System.out.println("-----------------------------------");
		System.out.println("Savings Account: ");
		Savings s = new Savings(1000);
		s.withdraw(600);
		
		
		System.out.println("------------------------------------");
		System.out.println("Current Account: ");
		Current c = new Current(7000);
		c.withdraw(7000);
	}
}
