package lab03.exercise03;
import java.util.Scanner;

public class Solution {
	public static char[] alterString(String str) {
		char[] ch = str.toCharArray();
		
		for (int i = 0; i < ch.length ; i++) {
			ch[i] = str.charAt(i);
			if(ch[i] =='a' || ch[i] =='A' || ch[i] =='e' || ch[i] =='E' || ch[i] =='i' || ch[i] =='I' || ch[i] =='o' || ch[i] =='O' || ch[i] =='u' || ch[i] =='U') {
			}else {
				ch[i] = (char) (ch[i] + 1);
			}
		}
		return ch;
	}
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter the string: ");  //JAVA
		String str = s.next();
		
		char[] c = alterString(str);     
		
		for(char character : c) {
			System.out.print(character);     //KAWA
		}
		s.close();

	}

	

}
