package lab03.exercise02;
import java.util.Scanner;

public class Solution {
	public static StringBuffer getImage(StringBuffer str) {
		str.reverse();
		return str;
	}
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the String: ");
		StringBuffer str = new StringBuffer(s.next());
		System.out.println(str+" | "+getImage(str));
		s.close();
	}

}
