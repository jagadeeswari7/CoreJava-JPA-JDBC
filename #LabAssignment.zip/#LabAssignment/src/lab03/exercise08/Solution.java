package lab03.exercise08;
import java.util.Scanner;

public class Solution {
	public static boolean positiveString(String str) {
		char[] ch = str.toCharArray();
		boolean b = false;
		
		for (int i = 0; i<ch.length-1; i++) {
			if(ch[i+1] < ch[i]) {
				return false;
			}
		}
		return true;
	}
	
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter the String: ");
		String str = s.next();
		
		System.out.println(positiveString(str));
		s.close();
	}

}
