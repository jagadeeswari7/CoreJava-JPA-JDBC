package lab03.exercise04;
import java.util.Scanner;

public class Solution {
	public static int modifyNumber(int number1) {
		String str = Integer.toString(number1);
		char[] ch = str.toCharArray();
		StringBuffer sb = new StringBuffer();
		
		for (int i = 0; i < ch.length-1 ; i++) {
			int a = Integer.parseInt(String.valueOf(ch[i]));
			int b = Integer.parseInt(String.valueOf(ch[i+1]));
			if(a > b ) {
			int n = a - b;
			sb.append(n);
			}else {
				int n = b -a ;
				sb.append(n);
			}
		}
		int a = Integer.parseInt(String.valueOf(ch[0]));
		int b = Integer.parseInt(String.valueOf(ch[ch.length-1]));
		if(a > b ) {
			int n = a - b;
			sb.append(n);
			}else {
				int n = b -a ;
				sb.append(n);
			}
		String str1 = sb.toString();
		int n = Integer.parseInt(str1);
		return n;
	}
	
	public static void main(String[] args) {
		Scanner s =  new Scanner(System.in);
		System.out.println("Enter the number: ");   //45862
        int number = s.nextInt();
        System.out.println(modifyNumber(number));   //13242
        s.close();
	}
}
