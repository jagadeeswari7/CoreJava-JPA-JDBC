package lab03.exercise01;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Solution {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the string: ");
		String str = s.nextLine();
		StringTokenizer str1 = new StringTokenizer(str," ");
	    	 
		int sum = 0;
		while (str1.hasMoreTokens()) {
			int a = Integer.parseInt(str1.nextToken());
            sum = sum + a;
		}
		
		System.out.println(sum);
		s.close();
	}

}
