package lab03.exercise05;
import java.util.Scanner;

public class Solution {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the string: ");
		String str = s.nextLine();
		
		char[] ch = str.toCharArray();
		int lines = 0;
		int words = 0;
		
		for (int i = 0; i < ch.length; i++) {
			if(ch[i] == '\n') {
				lines++;
			}else if(ch[i] == ' ') {
				words++;
			}
		}
		
		System.out.println(lines);
		System.out.println(words);
		System.out.println(ch.length);
		s.close();
	}

}
