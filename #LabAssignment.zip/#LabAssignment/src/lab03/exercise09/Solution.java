package lab03.exercise09;
import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.util.Scanner;

public class Solution {
	public static void main(String[] args) {
		Scanner s =  new Scanner(System.in);

		System.out.println("Enter the year: ");
		int year = s.nextInt();
		//Month month = DECEMBER;
		System.out.println("Enter the dayOfMonth: ");
		int dayOfMonth = s.nextInt();
		
		LocalDate start = LocalDate.of(year, Month.DECEMBER, dayOfMonth);
		LocalDate end = LocalDate.now();
		 
        Period period = start.until(end);
		
		System.out.println("Days:"+ period.getDays());
		System.out.println("Months:"+period.getMonths());
		System.out.println("Years:"+ period.getYears());
		s.close();

	}

}
