package lab09.exercise01;

import java.util.Scanner;

@FunctionalInterface
interface powers{
	public double power(double num1, double num2);
}
public class Solution {
  public static void main(String[] args) {
	 Scanner s = new Scanner(System.in);
	 powers result = (num1 , num2) -> {
		return Math.pow(num1, num2);
	 };
	 System.out.println("Enter the numbers : ");
	 System.out.println("Result is : "+result.power(s.nextDouble(), s.nextDouble()));
   }
}
