package lab09.exercise02;

import java.util.Scanner;

@FunctionalInterface
interface expression{
	public String space(String str);
}

public class Solution {
	public static void main(String[] args) {
		 Scanner s = new Scanner(System.in);
		 expression result = (str) ->{
			 return str.replaceAll(".", "$0 ");
		 };
		 System.out.println("Enter the string : ");
		 System.out.println("Result is : "+result.space(s.nextLine()));
    }
}