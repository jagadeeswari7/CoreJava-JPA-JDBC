package lab09.exercise05;

import java.util.Scanner;

public class Task {
  public static void doFactorial() {
	  Scanner s = new Scanner(System.in);
	  
	  int factorial = 1;
	  System.out.println("Enter the number : ");
	  int number= s.nextInt();
	  for(int i = 1; i<=number;i++) {
		  factorial = factorial * i;
	  }
	  System.out.println("Factorial is : "+factorial);
  }
}
