package lab09.exercise05;

public class Solution {
	public static void main(String[] args) {
    Runnable lambda1 = Task :: doFactorial;
	
	Thread worker1 = new Thread(lambda1);
	worker1.start();
    }
} 
