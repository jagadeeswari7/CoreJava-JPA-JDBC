package lab09.exercise04;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Solution {
	public static void main(String[] args) {
		 List<Employee> list = new ArrayList<>();

		Employee e1 = new Employee(207, "Sindhu", 7000);
		Employee e2 = new Employee(507, "Bolli", 12000);
		Employee e3 = new Employee(407, "jaggu", 15000);
		Employee e4 = new Employee(607, "Bolli sindhu", 4000);
	    
		list.add(e1);
		list.add(e2);
		list.add(e3);
		list.add(e4);
		
		Employee comparator  = new Employee(); 

        // Use instance method reference 
        Collections.sort(list, comparator::compareByName); 
        System.out.println("Sort by name :");
        for(Employee emp : list) {
 		   System.out.println(emp);
 	    }
	}
}
