package lab02.exercise04;

import java.util.Arrays;
import java.util.Scanner;

public class Solution2 {
	public static int[] modifyArray(int[] arr) {// 1, 3, 2, 3, 4, 2
		Arrays.sort(arr);// 1, 2, 2, 3, 3, 4
		int j=0;//  j=0
		// i=0
		//i<5
		int temp[] = new int[arr.length];
		for (int i = 0; i < arr.length-1; i++) {
				if(arr[i] != arr[i+1]) {
					 temp[j] = arr[i];
					 j++;
					 
				}
			}
		temp[j] = arr[arr.length-1];
		return temp;
	}
   public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	System.out.println("Enter the length of the array: ");
	int length = s.nextInt();
	int arr[] = new int[length];
	
	System.out.println("Enter the values in the array: ");
	for (int i = 0; i < arr.length; i++) {
		arr[i] = s.nextInt();
	}
	
	int[] p = modifyArray(arr);
	System.out.println("Resultant Array is:");
	for (int i = 0; i < p.length-1; i++) {
		if(p[i]==0) {
			
		}else
		System.out.print(p[i]+" ");
	}
	s.close();
   }
}

