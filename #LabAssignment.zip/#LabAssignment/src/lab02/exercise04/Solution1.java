package lab02.exercise04;

import java.util.Scanner;

public class Solution1 {
	public static int[] modifyArray (int[] arr) {
		int a[] = new int[arr.length];
		int temp=0;
		for(int i=0; i<arr.length-1; i++) {
			if(arr[i] != arr[i+1]) {
				a[i]=arr[i];
			}
		}
		for(int i=0; i<a.length; i++) 
		{
			 for(int j=i+1; j<a.length; j++)
		        {
				    if(a[i]>a[j]) {
					  temp = a[i];
					  a[i] = a[j];
					  a[j] = temp;
				    }
		        }
		}
		
		return a;
	}
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the length of the array: ");
		int length = s.nextInt();
		int arr[] = new int[length];
		
		System.out.println("Enter the values of the array: ");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = s.nextInt();
		}
		
		int[] p = modifyArray(arr);
		for (int i = 0; i < p.length; i++) {
			if(p[i]==0) {
				
			}else
			System.out.println(p[i]);
		}
	}
}
