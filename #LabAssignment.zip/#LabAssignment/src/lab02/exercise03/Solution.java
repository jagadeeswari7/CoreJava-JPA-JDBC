package lab02.exercise03;
import java.util.Arrays;
import java.util.Scanner;
 
public class Solution {
	public static int[] getSorted( int[] arr) {
		int[] a = new int[arr.length];
		for (int i = 0; i < arr.length; i++) {	
		 int reverse = 0;
		  while(arr[i] != 0) {
			int digit = arr[i] % 10;
            reverse = reverse * 10 + digit;
            arr[i] /= 10;
		  }
		  a[i] = reverse;
		}
		Arrays.sort(a);
		return a;
	}
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the length of the Array: ");
		int length = s.nextInt();
		int arr[] = new int[length];
		
		System.out.println("Enter the values of the array: ");
		for (int i = 0; i < arr.length; i++) {
			arr[i] = s.nextInt();
		}	
		int[] p = getSorted(arr);
		
		System.out.println("Resultant Array: ");
		for (int j = 0; j < p.length; j++) {
			System.out.print(p[j]+" ");
		}
		s.close();
	}
}
