package lab02.exercise02;

import java.util.Arrays;
import java.util.Scanner;

public class Solution {
	
	public static String[] sortStrings(String[] result) {	
		Arrays.sort(result);
		return result;
	}

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the length of the array:");
		int length = s.nextInt();
		String[] arr = new String[length];
		
		System.out.println("Enter the values of the array: ");
		for(int i=0; i<arr.length; i++) {
			arr[i] = s.next();
		}
		
		String[] p = sortStrings(arr);
		for (int i = 0; i < p.length; i++) {
	    int element = p[i].length();
		if(element%2!=0) {
			System.out.print(p[i].substring(0 , element/2).toUpperCase());
			System.out.print(p[i].substring(element/2).toLowerCase()+" ");
		}
		else {
			System.out.print(p[i].substring(0 , element/2).toLowerCase());
			System.out.print(p[i].substring(element/2).toUpperCase()+" ");
		}
		}
        s.close();
	}

}
