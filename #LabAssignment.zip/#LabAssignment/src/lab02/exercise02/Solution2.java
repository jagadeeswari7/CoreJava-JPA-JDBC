package lab02.exercise02;

import java.util.Arrays;
import java.util.Scanner;

public class Solution2 {
	public static String[] sortStrings(String[] result) {	
		Arrays.sort(result);
		return result;
	}

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the length of the array:");
		int length = s.nextInt();
		String[] arr = new String[length];
		
		System.out.println("Enter the values of the array: ");
		for(int i=0; i<arr.length; i++) {
			arr[i] = s.next();
		}
		
		String[] p = sortStrings(arr);
		int l=p.length;
		if(l%2!=0) {
			for(int j=0; j<(l/2)+1; j++) {
			System.out.print(p[j].toUpperCase()+" ");
			}
			for(int j=(l/2)+1; j<l; j++) {
				System.out.print(p[j].toLowerCase()+" ");
			}
		}
		else {
			for(int j=0; j<(l/2)+1; j++) {
			System.out.print(p[j].toLowerCase()+" ");
			}
			for(int j=(l/2)+1; j<l; j++) {
			System.out.print(p[j].toUpperCase()+" ");
			}
        s.close();
	}
  }
}
