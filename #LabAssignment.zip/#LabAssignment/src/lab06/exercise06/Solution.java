package lab06.exercise06;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Solution {
	public static List<Integer> votersList(Map<Integer, Integer> hs) {
		List<Integer> result = new ArrayList<Integer>();
		
		for(Map.Entry<Integer, Integer> entry : hs.entrySet()) {
			int age = entry.getValue();
			if(age >= 18) {
				result.add(entry.getKey());
			}
		}
		return result;
	}
  public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	
	System.out.println("Enter the range of voters: ");
	int n = s.nextInt();
	
	System.out.println("Enter the values in to the map: ");
	Map<Integer, Integer > hs = new HashMap<Integer , Integer>();
	for(int i = 0 ; i<n ; i++) {
	hs.put(s.nextInt(), s.nextInt());
	}
	
	System.out.println(votersList(hs));
  }
}
