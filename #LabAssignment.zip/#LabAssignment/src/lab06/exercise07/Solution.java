package lab06.exercise07;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Solution {
	public static List<Integer> getSorted(int[] arr) {
		List<Integer> result = new ArrayList<Integer>();
		
		for (int i = 0; i < arr.length; i++) {
			 int reverse = 0;
			  while(arr[i] != 0) {
				int digit = arr[i] % 10;
	            reverse = reverse * 10 + digit;
	            arr[i] /= 10;
			  }
			  result.add(reverse);
			}
		Collections.sort(result);
		return result;
	}
	 public static void main(String[] args) {
			Scanner s = new Scanner(System.in);
			
			System.out.println("Enter the length of the array : ");
			int n = s.nextInt();
			int[] arr = new int[n];
			
			System.out.println("Enter the values in the array : ");
			for (int i = 0; i < arr.length; i++) {
				arr[i] = s.nextInt();
			}
			
			System.out.println(getSorted(arr));
	 }
}
