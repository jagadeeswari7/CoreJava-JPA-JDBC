package lab06.exercise05;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Solution {
	public static int getSecondSmallest(int[] arr) {
     List<Integer> list = new ArrayList<Integer>();
	   
          for(int text : arr) {
	         list.add(text);
	      }
          Collections.sort(list);
		  return list.get(1);
	}
	
  public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	
	System.out.println("Enter the length of the array : ");
	int n = s.nextInt();
	int[] arr = new int[n];
	
	System.out.println("Enter the values in the array : ");
	for (int i = 0; i < arr.length; i++) {
		arr[i] = s.nextInt();
	}
	
	System.out.println(getSecondSmallest(arr));
  }
}
