package lab06.exercise02;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Solution {
	public static Map<Character, Integer> countChars(char[] arr) {
		Map<Character, Integer> counter = new HashMap<Character, Integer>();
		int count = 0;
		for (int i = 0; i < arr.length; i++) {
	            if (counter.containsKey(arr[i])) { 
	            // If char is present in Map, incrementing it's count by 1 
	                counter.put(arr[i], counter.get(arr[i]) + 1); 
	            } 
	            else { 
	           // If char is not present in Map, putting this char to Map with 1 as it's value 
	                counter.put(arr[i], 1); 
	            } 
		}
		return counter;
	}
  public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	System.out.println("Enter the length of the array: ");
	int n = s.nextInt();
	char[] arr = new char[n];
	System.out.println("Enter the characters in the array : ");
	for(int i=0; i<n; i++) {
		arr[i] = s.next().charAt(0);
	}
	System.out.println(countChars(arr));
  }
}
