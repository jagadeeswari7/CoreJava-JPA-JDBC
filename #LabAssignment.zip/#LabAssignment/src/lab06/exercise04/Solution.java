package lab06.exercise04;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Solution {
	public static Map<Integer,String> getStudents(Map<Integer, Integer> marks) {
		Map<Integer,String> grade = new HashMap<Integer,String>();
		for(Map.Entry e : marks.entrySet()) {
			int i = (int) e.getValue();
			if(i >= 90) {
				grade.put((Integer) e.getKey(), "Gold");
			}else if(i >= 80 && i < 90) {
				grade.put((Integer) e.getKey(), "Silver");
			}else {
				grade.put((Integer) e.getKey(), "Bronze");
			}
		}
		return grade;
	}
 public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	Map<Integer, Integer> marks = new HashMap<Integer, Integer>();
    System.out.println("Enter the number of students : ");
	int n = s.nextInt();
	System.out.println("Enter the details : ");
	for(int i = 0; i<n; i++) {
		marks.put(s.nextInt(),s.nextInt());
	}
	System.out.println(getStudents(marks));
 }
}
