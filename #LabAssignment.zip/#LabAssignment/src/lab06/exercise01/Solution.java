package lab06.exercise01;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

public class Solution {
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	
	Map<Integer,String> order = new HashMap<Integer,String>();
	order.put(1, "Sindhu");
	order.put(2, "Jaggu");
	order.put(3, "Bolli");
	order.put(4, "You");
	System.out.println(getValues(order));
}

public static List<String> getValues(Map<Integer, String> order) {
	List<String> values = new ArrayList<String>();
//	method - 1 :
//	for(int i=1; i<=order.size(); i++) {
//		values.add(order.get(i));
//	}
//  method - 2 :
//	for (Integer entry : order.keySet())  {
//		values.add(order.get(entry));
//	}
//  method - 3 :
//	order.forEach((Integer,String) -> values.add(String));
	for (Map.Entry<Integer,String> entry : order.entrySet())  {
		values.add(entry.getValue());
	}
	Collections.sort(values);
	return values;
}
}
