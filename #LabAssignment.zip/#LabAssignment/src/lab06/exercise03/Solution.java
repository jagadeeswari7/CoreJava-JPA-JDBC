package lab06.exercise03;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Solution {
	public static Map<Integer, Integer> getSquares(int[] arr) {
		Map<Integer, Integer> hs = new HashMap<Integer, Integer>();
		for(int a : arr) {
			hs.put(a, a*a);
		}
		return hs;
	}
	public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	System.out.println("Enter the length of the array: ");
	int n = s.nextInt();
	int[] arr = new int[n];
	System.out.println("Enter the values in the array : ");
	for(int i=0; i<n; i++) {
		arr[i] = s.nextInt();
	}
	System.out.println(getSquares(arr));
   }
}
