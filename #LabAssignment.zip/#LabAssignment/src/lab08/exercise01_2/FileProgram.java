package lab08.exercise01_2;

public class FileProgram {
public static void main(String[] args) {
	String source = "E:\\Module 1\\Core Java\\Workspace\\#LabAssignment\\src\\lab08\\exercise01_2\\source";
	String destination = "E:\\Module 1\\Core Java\\Workspace\\#LabAssignment\\src\\lab08\\exercise01_2\\destination";
	
	CopyDataThread task = new CopyDataThread(source, destination);
	Thread worker = new Thread(task);
	
	worker.start();
}
}
