package lab08.exercise01_2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyDataThread implements Runnable{
	String source = "";
	String destination="";
	FileInputStream fis = null;
	FileOutputStream fos = null;
	public CopyDataThread(String source, String destination) {	
		this.source = source;
		this.destination = destination;
	}
	
	   @Override
	   public void run() {
		   try {
			fis = new FileInputStream(source);
			fos = new FileOutputStream(destination);
		} catch (FileNotFoundException e1) {
			System.out.println("File not found!");
		}
		try {
			int ch;
			int count = 0 ;
			int i=10;
			while((ch = fis.read()) != -1) {
				fos.write(ch);
				count++;
				if(count%10==0) {
				System.out.println("10 characters are copied");
				Thread.sleep(5000);
		        }   
			}
		}catch (IOException e) {
		    System.out.println("IO Exception!");
		 }catch(InterruptedException e) {
			System.out.println("Thread is interrupted!");
		}
		System.out.println("Copied successfully");
	}
}
