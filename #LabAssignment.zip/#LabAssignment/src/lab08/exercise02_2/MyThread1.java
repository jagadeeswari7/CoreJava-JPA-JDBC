package lab08.exercise02_2;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class MyThread1 {
		public static void main(String[] args) {	
	        // Step 3 : Creating object of task
		    Solution3 hello = new Solution3();
		     
		   ExecutorService service = Executors.newFixedThreadPool(5);
		   // ExecutorService service = Executors.newSingleThreadExecutor();
		   service.execute(hello);
		   service.execute(hello);
		   service.execute(hello);
		   service.execute(hello);
		   service.execute(hello);
		
		   //shutdown service
		   service.shutdown();
		}
	}