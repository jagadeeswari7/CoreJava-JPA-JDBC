package lab08.exercise02_2;

import java.util.Timer;

public class Solution3 implements Runnable {

	@Override
	public void run() {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
	}
}
