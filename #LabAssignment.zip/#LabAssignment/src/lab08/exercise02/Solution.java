package lab08.exercise02;
import java.util.Date;
import java.util.*;
import java.util.TimerTask;

class MyThread extends TimerTask{
	
	@Override
	public void run() {
		System.out.println("Timer task started at:"+new Date());
		delayTask();
	    System.out.println("Timer task finished at:"+new Date());	
    }

	private void delayTask() {
		try {
	        Thread.sleep(10000);     
	    } catch (InterruptedException e) {
	        e.printStackTrace();
	    }
		
	}
}
public class Solution {
   public static void main(String[] args) {
	MyThread task = new MyThread();
	Timer time = new Timer();
    time.scheduleAtFixedRate(task, 0, 10*1000);    // executes for every ten seconds
  
   }
}

