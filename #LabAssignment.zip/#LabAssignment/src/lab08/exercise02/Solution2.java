package lab08.exercise02;
import java.util.Date;

class MyThread3 implements Runnable{

	@Override
	public void run() {
		while(true) {
			Date d = new Date();
			System.out.println(d);
			try {
				Thread.sleep(10000);
			}catch(InterruptedException e) {
				System.out.println("Thread is interrupted");
			}
		}
	}
}


public class Solution2 {
	 public static void main(String[] args) {
		   Thread worker = new Thread(new MyThread3());
		   worker.start();
	 }
}
