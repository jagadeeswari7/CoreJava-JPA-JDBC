package lab08.exercise01;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class FileProgram {
	public static void main(String[] args) {
		String sourcePath = "E:\\Module 1\\Core Java\\Workspace\\#LabAssignment\\src\\lab08\\exercise01\\source.txt";
		String destinationPath = "E:\\Module 1\\Core Java\\Workspace\\#LabAssignment\\src\\lab08\\exercise01\\destination.txt";
		File file = new File(sourcePath);
		FileInputStream fis = null;
		FileOutputStream fos = null;
		if(file.exists()) {
			try {
				fis = new FileInputStream(file);
				fos = new FileOutputStream(destinationPath);
				CopyDataThread task = new CopyDataThread(fis , fos);  
			}catch (FileNotFoundException e) {
				System.out.println("File not found");
			} 
		}else {
			System.out.println("File does not exist.");
		}
     }
}
