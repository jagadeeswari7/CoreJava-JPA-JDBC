package lab08.exercise01;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;


public class CopyDataThread extends Thread{

	public CopyDataThread(FileInputStream fis, FileOutputStream fos) {
		try {
			int ch;
			int count = 0 ;
			int i=10;
			while((ch = fis.read()) != -1) {
				fos.write(ch);
				count++;
				//System.out.print((char)ch);
				if(count%10==0) {
				System.out.println("10 characters are copied");
				Thread.sleep(5000);
		        }   
			}
		}catch (IOException e) {
		    System.out.println("IO Exception!");
		 }catch(InterruptedException e) {
			System.out.println("Thread is interrupted!");
		}
		System.out.println("Copied successfully");
	}

}
