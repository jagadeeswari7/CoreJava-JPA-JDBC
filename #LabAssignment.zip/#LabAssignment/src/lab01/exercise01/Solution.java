package lab01.exercise01;

import java.util.Scanner;

public class Solution {
	public static int sumOfCube(int number){
		int sum = 0;
		while(number != 0) {
			int remainder = number%10;
			sum = sum+(remainder*remainder*remainder);
			number = number/10;
		}
		return sum;
	}
	public static void main(String[] args) {
                              Scanner s = new Scanner(System.in);
                              System.out.println("Enter any number: ");
                              int number = s.nextInt();
                              int result = sumOfCube(number);
                              System.out.println("Result: "+result);
                              s.close();
	}
	
}


//342 : 3->27,4->64,2->8
