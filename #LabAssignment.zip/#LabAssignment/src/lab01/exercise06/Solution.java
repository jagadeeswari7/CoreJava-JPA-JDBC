package lab01.exercise06;
import java.util.Scanner;

public class Solution {

	public static int calculateDifference(int n) {
		int sum = 0;
		int square = 0;
		int wholesq = 0;
		for(int i = 1;i <= n;i++) {
			square = square + (i*i);
			wholesq = wholesq + i;
		}
		sum = square - (wholesq*wholesq);
		return sum;	
	}
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int number = s.nextInt();
		System.out.println(calculateDifference(number));
		s.close();
	}
}


// (1+4+9+16+25)=55
// (1+2+3+4+5)^2=225
