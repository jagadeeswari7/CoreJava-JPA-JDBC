package lab01.exercise07;
import java.util.Scanner;

public class Solution {
	public static boolean checkNumber(int number) {
		while(number != 0) {
			int remainder = number%10;
			number = number/10;
			int digit = number%10;
			if(remainder < digit) {
			    return false;
			}
		}
		return true;
	}

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int number = s.nextInt();
		System.out.println("Increasing number: "+checkNumber(number));
		s.close();
	}

}
