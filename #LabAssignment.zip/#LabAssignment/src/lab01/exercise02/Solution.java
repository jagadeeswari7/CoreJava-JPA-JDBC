package lab01.exercise02;
import java.util.Scanner;
public class Solution {

		public static void trafficLight(String button){
			/*if(button.equalsIgnoreCase("red")){
				System.out.println("STOP");
			}
			else if(button.equalsIgnoreCase("yellow")){
				System.out.println("READY");
			}
			else if(button.equalsIgnoreCase("green")){
				System.out.println("GO");
			}*/
			switch(button) {
			case "red":
				System.out.println("STOP");
				break;
			case "yellow":
				System.out.println("READY");
				break;
			case "green":
				System.out.println("GO");
				break;
			}
			
		}
		public static void main(String[] args) {		
			  Scanner s = new Scanner(System.in);
			  String button = s.nextLine();
			  trafficLight(button);
			  s.close();
		}
}


// Red Light Button-> STOP
// Yellow Light Button-> READY
// Green Light Button-> GO