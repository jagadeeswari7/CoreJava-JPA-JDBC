package lab01.exercise03;
import java.util.Scanner;
  //Recursion function
public class Solution1 {
	public static int fibonacci(int number) {  
		   if(number <= 2){    
		    	return 1;
		   }
		    else {
			return fibonacci(number-2)+fibonacci(number-1);
		   }    
	}
	public static void main(String[] args) {	
			Scanner s = new Scanner(System.in);
			int number = s.nextInt();
			for(int i = 1;i <= number;i++) {
			System.out.print(fibonacci(i)+" "); 
			}
	s.close();
    }
}
 

// 8 -> 1 1 2 3 5 8 13 21 