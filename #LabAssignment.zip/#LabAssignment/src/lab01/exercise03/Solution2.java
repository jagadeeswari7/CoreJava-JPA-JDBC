package lab01.exercise03;
import java.util.Scanner;
  //Non-recursion Function
public class Solution2 {
	public static void main(String[] args) {		
		Scanner s = new Scanner(System.in);
		int number = s.nextInt();
		int fib = 1;
		int fibPrevious = 1;
		if(number==1) {
	          System.out.println(number);
		}
		else {
		     System.out.print(fib+" "+fibPrevious);
		     for(int i = 2;i < number;i++) {
		     int sequence = fib+fibPrevious;
		     fib = fibPrevious;
		     fibPrevious = sequence;
		     System.out.print(" "+sequence);
		     }	
		}
	  s.close();
	 }
}


//9 -> 1 1 2 3 5 8 13 21 34