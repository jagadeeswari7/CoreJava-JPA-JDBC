package lab01.exercise05;
import java.util.Scanner;

public class Solution {
	public static int calculateSum(int n) {
		int sum = 0;
		for(int i = 1;i <= n;i++) {
			if(i%3==0 || i%5==0) {
			sum = sum+i;
			}
		}
		return sum;	
	}
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int number = s.nextInt();
		System.out.println(calculateSum(number));
        s.close();
	}
}


// 15-> 3+5+6+9+10+12+15 = 60