package lab01.exercise08;
import java.util.Scanner;

public class Solution {
	public static boolean checkNumber(int number) {
		for(int i = 1;i < number/2;i++) {
		if(Math.pow(2, i) == number) {
		return true;
		}
		}
		return false;
	}

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int number = s.nextInt();
		System.out.println("Powers of 2: " +checkNumber(number));
		s.close();
	}

}
