package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.Service;

public class EmployeeServiceApp {
public static void main(String[] args) {
	EmployeeService employeeService = new Service();
	
	Scanner sc = new Scanner(System.in);
	int choice;
	
	do {
		System.out.println("1:Get Employee");
		System.out.println("2:Find Insurance scheme");
		System.out.println("3:Display Employee details");
		System.out.println("4:Exit");
		choice = sc.nextInt();
		switch (choice) {
			case 1:
				System.out.println("Enter employee id");
				int id = sc.nextInt();
				System.out.println("Enter employee name");
				String name = sc.next();
				System.out.println("Enter employee salary");
				double salary = sc.nextDouble();
				System.out.println("Enter employee designation");
				String designation = sc.next();
				
				String insuranceScheme = employeeService.findInsuranceScheme(salary, designation);
				
				Employee employee = new Employee(id, name, salary, designation, insuranceScheme);
				employeeService.getEmployee(employee);
				break;
				
			case 2:
				System.out.println("Enter employee Id");
				id=sc.nextInt();
				employee = employeeService.showEmployee(id);
				if(employee!=null)
					System.out.println(employee.getInsuranceScheme());
				break;
				
			case 3:
				System.out.println("Enter employee Id");
				id=sc.nextInt();
				employee = employeeService.showEmployee(id);
				if(employee!=null)
					System.out.println(employee);
				break;
	
			default:
				System.out.println("Wrong Choice, Try again");
				break;
			}
	}while(choice!=4);
	sc.close();
  }
}
