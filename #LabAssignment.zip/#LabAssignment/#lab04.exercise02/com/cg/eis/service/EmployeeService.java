package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public interface EmployeeService {

	public boolean getEmployee(Employee employee);
	
	public String findInsuranceScheme(double salary, String designation);
	
	public Employee showEmployee(int id);
}
