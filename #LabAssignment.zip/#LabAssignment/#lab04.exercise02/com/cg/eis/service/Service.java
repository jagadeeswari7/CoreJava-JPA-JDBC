package com.cg.eis.service;

import java.util.HashMap;
import java.util.Map;

import com.cg.eis.bean.Employee;

public class Service implements EmployeeService{
	Map<Integer,Employee> employeeMap = new HashMap<Integer, Employee>();
	
	@Override
	public boolean getEmployee(Employee employee) {
		employeeMap.put(employee.getId(), employee);
		return true;
	}

	@Override
	public String findInsuranceScheme(double salary, String designation) {
		if(salary>5000 && salary<20000 && designation.equalsIgnoreCase("System Associate"))
			return "Scheme C";
		else if(salary>=200000 && salary<400000 && designation.equalsIgnoreCase("Analyst"))
			return "Scheme B";
		else if(salary>=400000 && designation.equalsIgnoreCase("Software Engineer"))
			return "Scheme A";
		else if(salary<5000 && designation.equalsIgnoreCase("Clerk"))
			return "No Scheme";
		return null;
	}

	@Override
	public Employee showEmployee(int id) {
		return employeeMap.get(id);
	}

}
